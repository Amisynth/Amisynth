split_storage = {}  # Almacena los valores de $textSplit[]
