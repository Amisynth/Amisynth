# Amisynth

Amisynth es un paquete para integrar funciones personalizadas en Discord.

## Instalación

Para instalar este paquete, usa `pip`:

```bash
pip install amisynth
