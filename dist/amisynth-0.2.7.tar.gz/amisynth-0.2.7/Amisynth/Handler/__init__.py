import xfox
from Amisynth.Collector import load_functions

def register_all():
    load_functions()
